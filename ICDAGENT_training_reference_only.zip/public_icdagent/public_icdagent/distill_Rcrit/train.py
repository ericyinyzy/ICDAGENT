import os
import json
import copy
import torch
import logging
import transformers
from random import shuffle
from transformers import Trainer
from torch.utils.data import Dataset
from dataclasses import dataclass, field
from peft import LoraConfig, get_peft_model
from typing import Dict, Optional, Sequence, List

SEED = 42
transformers.set_seed(SEED)
IGNORE_INDEX = -100


@dataclass
class ModelArguments:
    model_name_or_path: Optional[str] = field(default=None)
    is_lora: Optional[bool] = field(default=False)
    lora_rank: Optional[int] = field(default=16)
    target_modules: Optional[str] = field(default=None)
    use_flash_attention: Optional[bool] = field(default=False)


@dataclass
class DataArguments:
    data_path: str = field(default=None, metadata={"help": "Path to the training data."})


@dataclass
class TrainingArguments(transformers.TrainingArguments):
    cache_dir: Optional[str] = field(default=None)
    use_cache: bool = field(default=False, metadata={
        "help": "If set to True, the model will use caching for faster generation. Required False for gradient checkpointing."})
    model_max_length: int = field(
        default=32768,
        metadata={"help": "Maximum sequence length. Sequences will be right padded (and possibly truncated)."},
    )
    gradient_clipping: float = field(
        default=None
    )
    max_grad_norm: float = field(default=1.0)
    group_by_length: bool = field(default=True)
    deepspeed: Optional[str] = field(default=None)
    gradient_checkpointing: bool = field(default=True, metadata={
        "help": "If True, use gradient checkpointing to save memory at the expense of slower backward pass."})
    bf16: bool = field(default=True, metadata={
        "help": "Whether to use bf16 (mixed) precision instead of 32-bit. Requires Ampere or higher NVIDIA architecture or newer CPU supporting AVX512."})


def jsonl_load_icd(data_path):
    """Load a .jsonl file into a dictionary."""
    filepath = data_path
    res_dict_ls = []
    with open(filepath, 'r') as file:
        Samples = json.load(file)
    print(len(Samples))

    for sample in Samples:
        # if 'rational1' in sample:
        #     res_dict_ls.append({
        #         'input': sample['TEXT'],
        #         'input2': sample['TEXT_supp'],
        #         'input3': sample['rational'],
        #         'output': f"{sample['rational']}" + f"{sample['response']}"
        #     })
        # else:
        res_dict_ls.append({
            'input': sample['TEXT'],
            'input2': sample['TEXT_supp'],
            'input3': sample['rational'],
            'output': sample['thk_response']
        })

    shuffle(res_dict_ls)
    return res_dict_ls


def _tokenize_fn(strings: Sequence[str], tokenizer: transformers.PreTrainedTokenizer) -> Dict:
    """Tokenize a list of strings."""
    original_padding_side = tokenizer.padding_side
    tokenizer.padding_side = "left"

    tokenized_list = [
        tokenizer(
            text,
            return_tensors="pt",
            padding="longest",
            max_length=32768,
            truncation=True,
        )
        for text in strings
    ]

    tokenizer.padding_side = original_padding_side

    input_ids = labels = [tokenized.input_ids[0] for tokenized in tokenized_list]
    input_ids_lens = labels_lens = [
        tokenized.input_ids.ne(tokenizer.pad_token_id).sum().item() for tokenized in tokenized_list
    ]
    return dict(
        input_ids=input_ids,
        labels=labels,
        input_ids_lens=input_ids_lens,
        labels_lens=labels_lens,
    )


def preprocess(
        sources: Sequence[str],
        targets: Sequence[str],
        tokenizer: transformers.PreTrainedTokenizer,
) -> Dict:
    """Preprocess the data by tokenizing."""
    examples = [s + t for s, t in zip(sources, targets)]
    examples_tokenized, sources_tokenized = [_tokenize_fn(strings, tokenizer) for strings in (examples, sources)]
    input_ids = examples_tokenized["input_ids"]
    labels = copy.deepcopy(input_ids)
    for label, source_len in zip(labels, sources_tokenized["input_ids_lens"]):
        label[:source_len] = IGNORE_INDEX
    return dict(input_ids=input_ids, labels=labels)


class SupervisedDataset(Dataset):
    """Dataset for supervised fine-tuning."""

    def __init__(self, data_path: str, tokenizer: transformers.PreTrainedTokenizer):
        super(SupervisedDataset, self).__init__()
        tokenizer.padding_side = "left"

        logging.warning("Loading data...")
        list_data_dict = jsonl_load_icd(data_path)

        logging.warning("Formatting inputs...")
        sources = []
        targets = []

        # Using Qwen3's chat template format
        for example in list_data_dict:
            messages = [
                {
                    "role": "system",
                    'content': (
                        "You are an expert medical ICD-10 coding auditor. "
                        "Your mission is to rigorously audit a predicted ICD-10 code based on a patient's clinical note and the reasoning clues provided by a model.\n\n"
                        "You must perform a structured, multi-step validation:\n"
                        "1. **Evidence Verification:** Confirm that every reasoning clue is explicitly present in the clinical note. The evidence must be a direct quote or a very close paraphrase.\n"
                        "2. **Reasoning & Justification:** Ensure the link between the evidence and the inferred condition is medically sound and meets the official definition for the ICD-10 code.\n"
                ),
                },

                {
                    "role": "user",
                    "content": (
                        f"Here is the clinical Note:\n{example['input']}\n\n"
                        f"The target candidate ICD Code you need to judge:\n{example['input2']}\n\n"
                        f"The model's predicted rationale on this target code:\n{example['input3']}\n\n"
                        "Please think step by step to formulate your final judgment.\n\n"
                        "Your final output must strictly follow one of these formats:\n"
                        "1.If the code is correct: '|xxx| is a correct ICD code because the clinical note mentions...'\n"
                        "2.If the code is incorrect: '|xxx| is not a correct ICD code because... [state the specific reason, e.g., the evidence is missing, a more specific code is required, or it violates an exclusion rule].'\n"

                    ),
                },
            ]

            # Apply Qwen3's chat template
            source = tokenizer.apply_chat_template(
                messages,
                tokenize=False,
                add_generation_prompt=True
            )
            sources.append(source)
            targets.append(f"{example['output']}{tokenizer.eos_token}")

        print('*************')
        print(f"Sample source: {sources[12]}")
        print(f"Sample target: {targets[12]}")

        logging.warning("Tokenizing inputs... This may take some time...")
        data_dict = preprocess(sources, targets, tokenizer)
        self.input_ids = data_dict["input_ids"]
        self.labels = data_dict["labels"]

    def __len__(self):
        return len(self.input_ids)

    def __getitem__(self, i) -> Dict[str, torch.Tensor]:
        return dict(input_ids=self.input_ids[i], labels=self.labels[i])


@dataclass
class DataCollatorForSupervisedDataset(object):
    """Collate examples for supervised fine-tuning."""

    tokenizer: transformers.PreTrainedTokenizer

    def __call__(self, instances: Sequence[Dict]) -> Dict[str, torch.Tensor]:
        self.tokenizer.padding_side = "left"

        input_ids, labels = tuple([instance[key] for instance in instances] for key in ("input_ids", "labels"))

        batch = self.tokenizer.pad(
            {"input_ids": input_ids},
            padding=True,
            return_tensors="pt",
            pad_to_multiple_of=8,
        )

        labels_padded = []
        max_length = batch["input_ids"].size(1)

        for label in labels:
            pad_length = max_length - len(label)
            if pad_length > 0:
                labels_padded.append(torch.cat([
                    torch.full((pad_length,), IGNORE_INDEX, dtype=torch.long),
                    label
                ]))
            else:
                labels_padded.append(label[-max_length:])

        batch["labels"] = torch.stack(labels_padded)
        batch["attention_mask"] = batch["input_ids"].ne(self.tokenizer.pad_token_id)

        return batch


def make_supervised_data_module(tokenizer: transformers.PreTrainedTokenizer, data_args) -> Dict:
    """Make dataset and collator for supervised fine-tuning."""
    tokenizer.padding_side = "left"
    print(f"In make_supervised_data_module setting tokenizer.padding_side = {tokenizer.padding_side}")

    train_dataset = SupervisedDataset(tokenizer=tokenizer, data_path=data_args.data_path)
    data_collator = DataCollatorForSupervisedDataset(tokenizer=tokenizer)
    return dict(train_dataset=train_dataset, eval_dataset=None, data_collator=data_collator)


def train():
    parser = transformers.HfArgumentParser((ModelArguments, DataArguments, TrainingArguments))
    model_args, data_args, training_args = parser.parse_args_into_dataclasses()
    # print(model_args.lora_rank)
    # exit()

    # Configure Flash Attention 2
    attn_implementation = "flash_attention_2" if model_args.use_flash_attention else None

    # Setup tokenizer for Qwen3
    tokenizer = transformers.AutoTokenizer.from_pretrained(
        model_args.model_name_or_path,
        trust_remote_code=True,
    )

    # Set padding side
    tokenizer.padding_side = "left"

    # Ensure pad_token is set for Qwen3
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    print(f"Initialized tokenizer.padding_side = {tokenizer.padding_side}")
    print(f"Tokenizer pad_token: {tokenizer.pad_token}")
    print(f"Tokenizer eos_token: {tokenizer.eos_token}")

    # Create data module to get dataset size
    data_module = make_supervised_data_module(tokenizer=tokenizer, data_args=data_args)
    train_dataset = data_module["train_dataset"]

    # Calculate dataset size for DeepSpeed configuration
    dataset_size = len(train_dataset)
    print(f"Dataset size: {dataset_size}")


    # Load model with efficient settings for Qwen3
    model_kwargs = {
        "torch_dtype": torch.bfloat16,
        "trust_remote_code": True,
        "attn_implementation": attn_implementation,
        "low_cpu_mem_usage": True,
        # "device_map": None,  # Let DeepSpeed handle device placement
    }

    # Load Qwen3 model
    model = transformers.AutoModelForCausalLM.from_pretrained(
        model_args.model_name_or_path,
        **model_kwargs
    )

    # Resize token embeddings if needed
    if len(tokenizer) > model.get_input_embeddings().weight.size(0):
        model.resize_token_embeddings(len(tokenizer))

    if training_args.gradient_checkpointing:
        model.gradient_checkpointing_enable()

    model.config.use_cache = False
    for name, param in model.named_parameters():
        print(f"ori {name}: {param.shape}")

    print('######################################')

    # Apply LoRA for Qwen3
    if model_args.is_lora:
        # Define Qwen3 target modules
        if model_args.target_modules:
            target_modules = model_args.target_modules.split(",")
        else:
            # Default target modules for Qwen3-8B (similar to Qwen2.5)
            target_modules = ["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"]

        print(f"Using target modules for Qwen3: {target_modules}")

        config = LoraConfig(
            r=model_args.lora_rank,
            lora_alpha=2 * model_args.lora_rank,
            target_modules=target_modules,
            lora_dropout=0.05,
            bias='none',
            task_type="CAUSAL_LM",
        )

        model = get_peft_model(model, config)

        # Display trainable parameters
        trainable_params = 0
        all_param = 0
        for _, param in model.named_parameters():
            all_param += param.numel()
            if param.requires_grad:
                trainable_params += param.numel()
        print(
            f"trainable params: {trainable_params} || all params: {all_param} || trainable%: {100 * trainable_params / all_param:.2f}"
        )
        for name, param in model.named_parameters():
            status = "Trainable" if param.requires_grad else "Frozen"
            print(f"{name}: {param.shape}|{status}")

    # exit()

    # Create Trainer instance and train
    trainer = Trainer(
        model=model,
        tokenizer=tokenizer,
        args=training_args,
        **data_module
    )

    print("Starting training...")
    trainer.train()
    trainer.save_state()

    # Handle DeepSpeed wrapper (if any)
    if hasattr(model, 'module'):
        model = model.module

    # Synchronize if in distributed environment
    if torch.distributed.is_initialized():
        torch.distributed.barrier()

    # Save LoRA adapters without merging
    print("Saving LoRA adapters (no merge)...")
    model.save_pretrained(training_args.output_dir)
    # Save tokenizer
    tokenizer.save_pretrained(training_args.output_dir)


if __name__ == "__main__":
    train()