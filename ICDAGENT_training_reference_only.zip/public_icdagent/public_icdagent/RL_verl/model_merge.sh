
#export CUDA_HOME=/usr/local/cuda-12.6
#export PATH=/usr/local/cuda-12.6/bin:$PATH
#export LD_LIBRARY_PATH=/usr/local/cuda-12.6/lib64:$LD_LIBRARY_PATH

CUDA_VISIBLE_DEVICES=0 python -m verl.model_merger merge \
    --backend fsdp \
    --tie-word-embedding \
    --local_dir /path/to/chickpoint \
    --target_dir /path/to/R_crit_agent