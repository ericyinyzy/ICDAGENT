# Copyright 2024 Bytedance Ltd. and/or its affiliates
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""
Preprocess the GSM8k dataset to parquet format
"""

import argparse
from datasets import Dataset
import json
import os
import re

import datasets
import pandas as pd

from verl.utils.hdfs_io import copy, makedirs


def extract_solution(solution_str):
    solution = re.search("#### (\\-?[0-9\\.\\,]+)", solution_str)
    assert solution is not None
    final_solution = solution.group(0)
    final_solution = final_solution.split("#### ")[1].replace(",", "")
    return final_solution
code_descript = json.load(open('/path/to/code_descriptions_ICD10.json', 'r'))
# Helper functions
def map_mc2mctxt(codes):
    return "\n".join(f"{code}:{code_descript[code.replace('.','')]}" for code in codes)
def map_mc2mctxt2(codes):
    return "\n".join(f"{code}({code_descript[code.replace('.','')]})" for code in codes)

def process_dataset_list(dataset_list, split, data_source):
    """处理list格式的数据集"""
    instruction_following = 'Let\'s think step by step and output the final answer after "####".'

    processed_data = []

    for idx, example in enumerate(dataset_list):
        # 创建副本避免修改原数据
        example_copy = example.copy()
        #
        #
        # question_raw = example_copy.get("question", "")
        # answer_raw = example_copy.get("answer", "")
        #
        # question = question_raw + " " + instruction_following
        # solution = extract_solution(answer_raw)
        cl_note = example_copy['TEXT']
        spe_ans = example_copy['rational']
        code_desc = map_mc2mctxt([example_copy['code']])
        code_supp=map_mc2mctxt2([example_copy['code']])
        # print(example_copy.keys())
        if 'gemini_score_dict' in example_copy:
            solution=example_copy['code']+'##'+example_copy['correctness']+'##'+str(example_copy['gemini_score_dict'][example_copy['code']])
            # if int(solution.split('##')[-1])*0.1 not in [0.2,0.4,0.6,0.8]:
            #     print(int(solution.split('##')[-1])*0.1)
            #     raise ValueError
        else:
            solution = example_copy['code'] + '##' + example_copy['correctness'] + '##' + str(5)
            # if int(solution.split('##')[-1]) * 0.1 not in [0.5]:
            #     raise ValueError
        if solution.split('##')[1]!='Yes' and solution.split('##')[1] !='No':
            raise ValueError
        # answer_raw=
        messages = [
            {
                "role": "system",
                'content': (
                    "You are an expert medical ICD-10 coding auditor. "
                    "Your mission is to rigorously audit a predicted ICD-10 code based on a patient's clinical note and the reasoning clues provided by a model.\n\n"
                    "You must perform a structured, multi-step validation:\n"
                    "1. **Evidence Verification:** Confirm that every reasoning clue is explicitly present in the clinical note. The evidence must be a direct quote or a very close paraphrase.\n"
                    "2. **Reasoning & Justification:** Ensure the link between the evidence and the inferred condition is medically sound and meets the official definition for the ICD-10 code.\n"
                ),
            },

            {
                "role": "user",
                "content": (
                    f"Here is the clinical Note:\n{example['input']}\n\n"
                    f"The target candidate ICD Code you need to judge:\n{example['input2']}\n\n"
                    f"The model's predicted rationale on this target code:\n{example['input3']}\n\n"
                    "Please think step by step to formulate your final judgment.\n\n"
                    "Your final output must strictly follow one of these formats:\n"
                    "1.If the code is correct: '|xxx| is a correct ICD code because the clinical note mentions...'\n"
                    "2.If the code is incorrect: '|xxx| is not a correct ICD code because... [state the specific reason, e.g., the evidence is missing, a more specific code is required, or it violates an exclusion rule].'\n"

                ),
            },
        ]

        data = {
            "data_source": data_source,
            "prompt": messages,
            "ability": "icdcoding",
            "reward_model": {"style": "rule", "ground_truth": solution},
            "extra_info": {
                "split": split,
                "index": idx,
                "answer": solution,
                "question": example_copy['code'],
            },
        }
        # print(data)
        # exit()
        processed_data.append(data)

    return processed_data


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--local_dir", default="/path/to/icdcoding_rl_RQS")
    parser.add_argument("--hdfs_dir", default=None)

    args = parser.parse_args()

    data_source = "mimic4/icd9"


    train_dataset = json.load(open('/path/to/icd10_10K_rl_train.json','r'))#[dict(item) for item in dataset["train"].select(range(8))]
    test_dataset = json.load(open('/path/to/icd10_10K_rl_val.json','r'))#[dict(item) for item in dataset["test"].select(range(8))]

    print(f"Train dataset length: {len(train_dataset)}, type: {type(train_dataset)}")
    print(f"Test dataset length: {len(test_dataset)}, type: {type(test_dataset)}")

    # 处理数据集
    processed_train = process_dataset_list(train_dataset, "train", data_source)
    processed_test = process_dataset_list(test_dataset, "test", data_source)

    local_dir = args.local_dir
    hdfs_dir = args.hdfs_dir

    # 确保目录存在
    os.makedirs(local_dir, exist_ok=True)

    # 转换为DataFrame并保存为parquet
    Dataset.from_list(processed_train).to_parquet(os.path.join(local_dir, "train_icd10.parquet"))
    Dataset.from_list(processed_test).to_parquet(os.path.join(local_dir, "test_icd10.parquet"))


    if hdfs_dir is not None:
        makedirs(hdfs_dir)
        copy(src=local_dir, dst=hdfs_dir)