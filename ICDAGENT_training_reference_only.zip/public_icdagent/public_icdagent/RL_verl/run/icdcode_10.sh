#!/bin/bash

export CUDA_VISIBLE_DEVICES=0,1

PROJECT_NAME=icd10
EXPERIMENT_NAME=icd10_critical

TRAIN_DATA=/path/to/icdcoding_rl_RQS/train_icd10.parquet
VAL_DATA=/path/to/icdcoding_rl_RQS/test_icd10.parquet
BASE_MODEL=/path/to/Qwen3-4B-icd10

# Auto-detect number of GPUs from CUDA_VISIBLE_DEVICES
N_GPUS=$(echo $CUDA_VISIBLE_DEVICES | tr ',' '\n' | wc -l)

# Reward Configuration - Choose one by uncommenting
# REWARD_CONFIG="detector_only"     # detector only
# REWARD_CONFIG="unit_test_only"    # unit test only
# REWARD_CONFIG="detector_safety"   # detector + safety unit test
REWARD_CONFIG="hybrid"              # hybrid mix (current: scpd=0.5, ut=0.5)

export WANDB_API_KEY="YOUR_KEY_HERE"
export VLLM_ATTENTION_BACKEND=XFORMERS
#export VLLM_USE_V1=0

# ---------------------------------------------------------------------------

TIME_TAG=$(date +%Y%m%d-%H%M%S)

# Set reward ratios based on configuration
case $REWARD_CONFIG in
    "detector_only")
        SAFETY_RATIO=0.0
        MYPY_RATIO=0.0
        SCPD_RATIO=1.0
        UT_RATIO=0.0
        CONFIG_DESC="Detector Only"
        ;;
    "unit_test_only")
        SAFETY_RATIO=0.0
        MYPY_RATIO=0.0
        SCPD_RATIO=0.0
        UT_RATIO=1.0
        CONFIG_DESC="Unit Test Only"
        ;;
    "detector_safety")
        SAFETY_RATIO=0.5
        MYPY_RATIO=0.0
        SCPD_RATIO=0.0
        UT_RATIO=1.0
        CONFIG_DESC="Detector + Safety Unit Test"
        ;;
    "hybrid")
        SAFETY_RATIO=0.0
        MYPY_RATIO=0.0
        SCPD_RATIO=0.5
        UT_RATIO=0.5
        CONFIG_DESC="Hybrid (SCPD + Unit Test)"
        ;;
    *)
        echo "Invalid REWARD_CONFIG: $REWARD_CONFIG"
        exit 1
        ;;
esac

echo "----------------------------------------"
echo "Project: $PROJECT_NAME"
echo "Experiment: $EXPERIMENT_NAME-$TIME_TAG"
echo "Base Model: $BASE_MODEL"
echo "Train Data: $TRAIN_DATA"
echo "Validation Data: $VAL_DATA"
echo "CUDA_VISIBLE_DEVICES: $CUDA_VISIBLE_DEVICES"
echo "Number of GPUs: $N_GPUS"
echo "----------------------------------------"
echo "Reward Configuration: $CONFIG_DESC"
echo "Safety Ratio: $SAFETY_RATIO"
echo "Mypy Ratio: $MYPY_RATIO"
echo "SCPD Ratio: $SCPD_RATIO"
echo "UT Ratio: $UT_RATIO"
echo "----------------------------------------"

#read -p "Do you want to continue? (y/n): " choice
#if [[ $choice != "y" ]]; then
#    echo "Exiting..."
#    exit 1
#fi

mkdir -p ./log/$PROJECT_NAME

PYTHONUNBUFFERED=1 python3 -m verl.trainer.main_ppo \
 data.train_files=$TRAIN_DATA \
 data.val_files=$VAL_DATA \
 data.train_batch_size=128 \
 data.max_prompt_length=12288 \
 data.max_response_length=2048 \
 actor_rollout_ref.model.path=$BASE_MODEL \
 actor_rollout_ref.model.use_shm=True \
 actor_rollout_ref.model.lora_rank=32 \
 actor_rollout_ref.model.lora_alpha=32 \
 actor_rollout_ref.model.target_modules=[q_proj,k_proj,v_proj,o_proj,gate_proj,up_proj,down_proj] \
 actor_rollout_ref.rollout.load_format=safetensors \
 actor_rollout_ref.rollout.layered_summon=False \
 actor_rollout_ref.ref.fsdp_config.param_offload=False \
 actor_rollout_ref.actor.ulysses_sequence_parallel_size=1 \
 actor_rollout_ref.rollout.max_num_batched_tokens=16384 \
 actor_rollout_ref.rollout.enforce_eager=False \
 actor_rollout_ref.rollout.enable_chunked_prefill=True \
 actor_rollout_ref.actor.optim.lr=5e-5 \
 actor_rollout_ref.actor.ppo_mini_batch_size=128 \
 actor_rollout_ref.actor.ppo_micro_batch_size_per_gpu=1 \
 actor_rollout_ref.rollout.log_prob_micro_batch_size_per_gpu=1 \
 actor_rollout_ref.rollout.tensor_model_parallel_size=2 \
 actor_rollout_ref.rollout.gpu_memory_utilization=0.25 \
 actor_rollout_ref.ref.log_prob_micro_batch_size_per_gpu=1 \
 actor_rollout_ref.actor.fsdp_config.fsdp_size=2 \
 actor_rollout_ref.actor.fsdp_config.param_offload=False \
 actor_rollout_ref.actor.fsdp_config.optimizer_offload=False \
 actor_rollout_ref.rollout.name=vllm \
 critic.optim.lr=5e-5 \
 critic.model.path=$BASE_MODEL \
 critic.model.fsdp_config.fsdp_size=2 \
 critic.model.fsdp_config.param_offload=False \
 critic.model.fsdp_config.optimizer_offload=False \
 critic.ppo_micro_batch_size_per_gpu=1 \
 algorithm.kl_ctrl.kl_coef=0.001 \
 trainer.logger=console \
 trainer.project_name=$PROJECT_NAME \
 trainer.experiment_name=$EXPERIMENT_NAME-$TIME_TAG \
 trainer.val_before_train=False \
 trainer.n_gpus_per_node=2 \
 trainer.nnodes=1 \
 trainer.save_freq=5 \
 trainer.test_freq=5 \
 trainer.total_epochs=3

 #change following when run gpu
 #tensor_model_parallel_size fsdp_size x 2 n_gpus_per_node
