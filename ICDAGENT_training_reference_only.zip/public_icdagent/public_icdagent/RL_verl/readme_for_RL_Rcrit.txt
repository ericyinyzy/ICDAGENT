Our reinforcemnet learning is designed based on the verl framework, to run this framework, you need:
1. python examples/data_preprocess/icd_coding.py to generate .parquet training files
2. bash run/icdcode_10.sh to start RL training! (rationale aware reward is in verl/utils/reward_score/icd9critical.py)

