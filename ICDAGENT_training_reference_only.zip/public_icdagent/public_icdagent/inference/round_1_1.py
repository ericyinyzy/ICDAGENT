
import torch
from transformers import AutoTokenizer
from vllm import LLM, SamplingParams
import json
import os
from vllm.lora.request import LoRARequest

tokenizer = AutoTokenizer.from_pretrained("/path/to/HuatuoGPT-o1-8B")
sampling_params = SamplingParams(temperature=0.7, top_p=0.8, repetition_penalty=1.05, max_tokens=8192)
llm = LLM(
        model="/path/to/HuatuoGPT-o1-8B",
        dtype="bfloat16",
        max_lora_rank=32,
        tensor_parallel_size=torch.cuda.device_count(),
        gpu_memory_utilization=0.9,
        trust_remote_code=True,
        max_model_len=16384,
        enforce_eager=False,
        enable_lora=True
        # Remove peft_model_path parameter
    )
lora_request = LoRARequest(
        "lora_adapter",  # human-readable name
        1,  # unique ID for the adapter
        '/path/to/R_code_agent/checkpoint-2811'  # path to LoRA weights
    )

notes = json.load(open('/path/to/1ksamples_wcorelation_mimiciv_ICD10.json', 'r'))
code_descript = json.load(open('/path/to/code_descriptions.json', 'r'))
code_and_subcodes = json.load(open('/path/to/code_and_subcodes.json', 'r'))

# Helper functions
def map_mc2mctxt(codes):
    return "\n".join(f"{code}: {code_descript[code]}" for code in codes if code in code_descript)


batch_size = 12
input_batches = [notes[i:i + batch_size] for i in range(0, len(notes), batch_size)]

store_list = []
import re

def extract_icd_codes(text):

    pattern = r'\|([0A-Z][^|]*)\|'
    return re.findall(pattern, text)

def extract_icd_codes_star(text):
    pattern = r'\*\*([VE]?\d{1,3}(?:\.\d{1,2})?)\*\*'
    return re.findall(pattern, text)
count=0
for batch in input_batches:
    prompt_batch, meta_batch = [], []
    print(f'start processing on batch {count},total {len(input_batches)} batches')
    count+=1

    for entry in batch:
        end_flag=0
        cl_note = entry['TEXT']
        label_codes=entry['labels']

        messages = [
            {
                "role": "system",
                "content": (
                    "You are a helpful assistant specialized in medical ICD-10 coding. "
                    "You will be given a clinical note. "
                    "Your task is to extract the correct ICD-10 codes that match the clinical note. "
                    "For each extracted code (formatted as '|xxx|'), you must:"
                    "- Identify the specific clues in the clinical note that support the use of this code."
                    "- Explain in detail how these clues justify the code '|xxx|'."
                    "You must follow these output formats:"
                    "1. Each section is a clue and a reasoning to the correct codes."
                    "2. You are extracting ICD-10 codes, NOT ICD-9 codes!!!!"
                    "3. Seperate each section with '\n\n'."
                    "4. Finally, for the output format, you must directly and strictly output N paragraphs, which contain the rationals of N codes."
                    "5. VERY IMPORTANT: each code must be presented as |xxx|, YOU MUST USE || to denote a code!!!!"
                    "6. Your final sentence must be 'Therefore, the correct icd codes are |xxx1||xxx2|...(Your extracted codes.)'"

                ),
            },
            {
                "role": "user",
                "content": (
                    f"Clinical Note:\n{cl_note}\n\n"
                    "Predict the correct ICD-10 codes based on the given note. Don't forget you must have a"
                    " conclusion sentence, it must be 'Therefore, the correct icd codes are |xxx1||xxx2|...(Your extracted codes.)"
                    ),
            },
        ]

        text_prompt = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)

        prompt_batch.append(text_prompt)
        meta_batch.append({
            'subject_id': entry['subject_id'],
            'hadm_id': entry['hadm_id'],
            'TEXT':cl_note,
            'labels': label_codes,
            'end_flag':end_flag
        })

    # Batch inference
    outputs = llm.generate(prompt_batch, sampling_params,lora_request=lora_request)


    for meta, output in zip(meta_batch, outputs):
        generated_text = output.outputs[0].text
        print(generated_text)
        print(meta['labels'])
        extracted_labels=extract_icd_codes(generated_text)
        if len(extracted_labels)==0:
            extracted_labels = extract_icd_codes_star(generated_text)
        # exit()
        print(extracted_labels)
        if meta['end_flag']==0:
            store_list.append({
                'subject_id': meta['subject_id'],
                'hadm_id': meta['hadm_id'],
                'TEXT':meta['TEXT'],
                'ans': generated_text,
                'label': meta['labels'],
                'extracted_labels': extracted_labels
            })
        else:
            store_list.append({
                'subject_id': meta['subject_id'],
                'hadm_id': meta['hadm_id'],
                'TEXT': meta['TEXT'],
                'ans': generated_text,
                'label': meta['labels'],
                'extracted_labels': []
            })

# Final save
os.makedirs('output', exist_ok=True)
with open('output/round_1_1.json', 'w') as file:
    json.dump(store_list, file, indent=4)


