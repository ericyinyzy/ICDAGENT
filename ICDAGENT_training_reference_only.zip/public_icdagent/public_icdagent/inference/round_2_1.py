
import torch
from transformers import AutoTokenizer
from vllm import LLM, SamplingParams
import json
import os
from vllm.lora.request import LoRARequest
import time
import re

# Initialize tokenizer and model
tokenizer = AutoTokenizer.from_pretrained("/path/to/HuatuoGPT-o1-8B")
sampling_params = SamplingParams(temperature=0.7, top_p=0.8, repetition_penalty=1.05, max_tokens=8192)
llm = LLM(
        model="/path/to/HuatuoGPT-o1-8B",
        dtype="bfloat16",
        max_lora_rank=32,
        tensor_parallel_size=torch.cuda.device_count(),
        gpu_memory_utilization=0.9,
        trust_remote_code=True,
        max_model_len=32768,
        enforce_eager=False,
        enable_lora=True
        # Remove peft_model_path parameter
    )
lora_request = LoRARequest(
        "lora_adapter",  # human-readable name
        1,  # unique ID for the adapter
        '/path/to/R_code_agent/checkpoint-2811'  # path to LoRA weights
    )

notes = json.load(open('output/round_1_2_store.json', 'r'))
new_note_dicts={}
for dict in notes:
    index=dict['subject_id']+'_'+dict['hadm_id']

    if index not in new_note_dicts:
        new_note_dicts[index]={
                'subject_id': dict['subject_id'],
                'hadm_id': dict['hadm_id'],
                'clnote': dict['clnote'],
                'code_desc': [dict['code']],
            }
    else:
        new_note_dicts[index]['code_desc'].append(dict['code'])
new_note=[]
for k,v in new_note_dicts.items():
    new_note.append(v)


code_descript = json.load(open('/path/to/code_descriptions_ICD10.json', 'r'))
code_and_subcodes = json.load(open('/path/to/code_and_subcodes.json', 'r'))

# Helper functions
def map_mc2mctxt(codes):
    return "\n".join(f"{code}: {code_descript[code]}" for code in codes if code in code_descript)

# Prepare batch data
batch_size = 12
input_batches = [new_note[i:i + batch_size] for i in range(0, len(new_note), batch_size)]

store_list = []
import re

def extract_icd_codes(text):
    # 提取所有以0或字母开头的代码，不限制后面的格式
    pattern = r'\|([0A-Z][^|]*)\|'
    return re.findall(pattern, text)

def extract_icd_codes_star(text):
    pattern = r'\|([0A-Z][^|]*)\|'
    return re.findall(pattern, text)

def extract_rational(generated_text, target_string):
    """
    提取thinking和response之间的内容并进行分段处理

    Args:
        generated_text: 包含## Thinking和## Final Response的文本
        target_string: 目标ICD代码字符串，例如"|284.11|"

    Returns:
        抽取的rational文本
    """


    if target_string not in generated_text:# == -1 or response_start == -1:
        return None


    thinking_content = generated_text.split('## Final Response')[0]

    # 按\n\n分段
    paragraphs = thinking_content.split('\n\n')
    paragraphs = [p.strip() for p in paragraphs if p.strip()]  # 去除空段落


    matching_paragraphs = []
    for paragraph in paragraphs:
        if target_string in paragraph:
            matching_paragraphs.append(paragraph)

    return '\n\n'.join(matching_paragraphs)


# 测试用例1：多段情况
exist_list=[]
output_file={}

for batch in input_batches:
    prompt_batch, meta_batch = [], []

    for entry in batch:
        end_flag=0

        cl_note=entry['clnote']
        # feedback=entry['feedback']
        code_desc='\n\n'.join(entry['code_desc'])
        messages = [
            {
                "role": "system",
                "content": (
                    "You are a helpful assistant specialized in medical ICD-10 coding. "
                    "You will be given a clinical note and a candidate code set. "
                    "Your task is to extract the correct ICD-10 codes that match the clinical note from the candidate code set. "
                    "For each extracted code (formatted as '|xxx|'), you must:"
                    "- Identify the specific clues in the clinical note that support the use of this code."
                    "- Explain in detail how these clues justify the code '|xxx|'."
                    "You must follow these output formats:"
                    "1. Each section is a clue and a reasoning to the correct codes."
                    "2. You are extracting ICD-10 codes, NOT ICD-9 codes!!!!"
                    "3. Seperate each section with '\n\n'."
                    "4. Finally, for the output format, you must directly and strictly output N paragraphs, which contain the rationals of N codes."
                    "5. VERY IMPORTANT: each code must be presented as |xxx|, YOU MUST USE || to denote a code!!!!"
                    "6. Your final sentence must be 'Therefore, the correct icd codes are |xxx1||xxx2|...(Your extracted codes.)'"

                ),
            },
            {
                "role": "user",
                "content": (
                    f"Clinical Note:\n{cl_note}\n\n"
                    f"Candidate Code Set:\n{code_desc}\n\n"
                    "Predict the correct ICD-10 codes based on the given note. Don't forget you must have a"
                    "conclusion sentence, it must be 'Therefore, the correct icd codes are |xxx1||xxx2|...(Your extracted codes.). Also, don't forget you must extract codes form the candidate code set!!!"
                ),
            },
        ]


        text_prompt = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
        prompt_batch.append(text_prompt)
        meta_batch.append({
            'subject_id': entry['subject_id'],
            'hadm_id': entry['hadm_id'],
            'clnote':cl_note,
            # 'labels': label_codes,
            'code':code_desc,
            'end_flag':end_flag
        })

    # Batch inference
    outputs = llm.generate(prompt_batch, sampling_params,lora_request=lora_request)


    for meta, output in zip(meta_batch, outputs):
        generated_text = output.outputs[0].text
        print(generated_text)
        # print(meta['labels'])
        extracted_labels = extract_icd_codes(generated_text)
        if len(extracted_labels) == 0:
            extracted_labels = extract_icd_codes_star(generated_text)
        # exit()
        print(extracted_labels)
        if meta['end_flag'] == 0:
            store_list.append({
                'subject_id': meta['subject_id'],
                'hadm_id': meta['hadm_id'],
                'clnote': meta['clnote'],
                'ans': generated_text,
                # 'label': meta['labels'],
                'extracted_labels': extracted_labels
            })
        else:
            store_list.append({
                'subject_id': meta['subject_id'],
                'hadm_id': meta['hadm_id'],
                'clnote': meta['clnote'],
                'ans': generated_text,
                # 'label': meta['labels'],
                'extracted_labels': []
            })

with open('output/round_2_1.json', 'w') as file:
    json.dump(store_list, file, indent=4)