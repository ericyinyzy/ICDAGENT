import torch
from transformers import AutoTokenizer
from vllm import LLM, SamplingParams
import json
import os
import re
from vllm.lora.request import LoRARequest

# Initialize tokenizer and model
import torch
from safetensors import safe_open

from safetensors import safe_open
from safetensors.torch import save_file
import torch


tokenizer = AutoTokenizer.from_pretrained("/path/to/R_crit_agent")

sampling_params = SamplingParams(temperature=0.6, top_p=0.95, top_k=20, max_tokens=2048)
llm = LLM(
    model="/path/to/R_crit_agent",
    dtype="bfloat16",
    tensor_parallel_size=torch.cuda.device_count(),
    # max_lora_rank=32,
    gpu_memory_utilization=0.9,
    trust_remote_code=True,
    max_model_len=32768,
    enforce_eager=False,
    # enable_lora=True
    # Remove peft_model_path parameter
)
notes = json.load(
    open('output/round_1_1.json', 'r'))#[:50]
clinical_note_file = json.load(open('/path/to/1ksamples_wcorelation_mimiciv_ICD10.json', 'r'))
for (x1, x2) in zip(notes, clinical_note_file):
    x1['TEXT'] = x2['TEXT']
code_descript = json.load(open('/path/to/code_descriptions_ICD10.json', 'r'))


# Helper functions
def map_mc2mctxt(codes):
    return "\n".join(f"{code}: {code_descript[code.replace('.','')]}" for code in codes if code in code_descript)




def extract_icd_codes(text):
    pattern = r'\|([0A-Z][^|]*)\|'
    return re.findall(pattern, text)


store_list = []


def seperate_ans(ans, codes):
    code_dict = {}
    for para in ans:
        sub_codes = extract_icd_codes(para)
        if len(sub_codes) != 0:
            sub_codes = ['|' + code + '|' for code in sub_codes]
            sub_codes = list(set(sub_codes))
        for code in sub_codes:
            if code not in code_dict:
                code_dict[code] = []
                code_dict[code].append(para)
            else:
                code_dict[code].append(para)
    for k, v in code_dict.items():
        if len(v) == 1:
            code_dict[k] = v[0]
        elif len(v) > 1:
            code_dict[k] = '\n\n'.join(v)
        else:
            raise ValueError
    return code_dict


count = 0
out_list=[]
print(len(notes))
batch_size = 12
for entry in notes:
    extracted_codes = ['|' + code + '|' for code in set(entry['extracted_labels'])]
    if len(extracted_codes) > 0:
        ans = entry['ans']
        xxx = ans.split('## Final Response')[0]
        # print(xxx)
        kk = xxx.split('\n\n')
        sep_ans_dict = seperate_ans(kk, extracted_codes)
        x_codes = list(sep_ans_dict.keys())
        cl_note = entry['TEXT']
        label_codes = entry['label']

        code_batches = [x_codes[i:i + batch_size] for i in range(0, len(x_codes), batch_size)]
        text_list = {}
        correct_codes = []
        for batch in code_batches:
            prompt_batch, meta_batch = [], []

            for code in batch:
                spe_ans = sep_ans_dict[code]
                code_desc = map_mc2mctxt([code])

                messages = [
                    {
                        "role": "system",
                        'content': (
                            "You are an expert medical ICD-10 coding auditor. "
                            "Your mission is to rigorously audit a predicted ICD-10 code based on a patient's clinical note and the reasoning clues provided by a model.\n\n"
                            "You must perform a structured, multi-step validation:\n"
                            "1. **Evidence Verification:** Confirm that every reasoning clue is explicitly present in the clinical note. The evidence must be a direct quote or a very close paraphrase.\n"
                            "2. **Reasoning & Justification:** Ensure the link between the evidence and the inferred condition is medically sound and meets the official definition for the ICD-10 code.\n"
                        ),
                    },

                    {
                        "role": "user",
                        "content": (
                            f"Here is the clinical Note:\n{cl_note}\n\n"
                            f"The target candidate ICD Code you need to judge:\n{code_desc}\n\n"
                            f"The model's predicted rationale on this target code:\n{spe_ans}\n\n"
                            "Please think step by step to formulate your final judgment.\n\n"
                            "Your final output must strictly follow one of these formats:\n"
                            "1.If the code is correct: '|xxx| is a correct ICD code because the clinical note mentions...'\n"
                            "2.If the code is incorrect: '|xxx| is not a correct ICD code because... [state the specific reason, e.g., the evidence is missing, a more specific code is required, or it violates an exclusion rule].'\n"

                        ),
                    },
                ]

                text_prompt = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
                prompt_batch.append(text_prompt)
                meta_batch.append({
                    'code': code,
                    'rational':spe_ans,
                    'code_desc': code_desc,
                })

            outputs = llm.generate(prompt_batch, sampling_params)

            for meta, output in zip(meta_batch, outputs):

                generated_text = output.outputs[0].text
                print(meta['code'])
                print('#####################')
                print(generated_text)
                if 'is a correct' in generated_text:
                    correct_codes.append(meta['code'])
                    text_list[meta['code']]=generated_text.split('## Final Response')[-1]
                else:
                    store_list.append({
                        'subject_id': entry['subject_id'],
                        'hadm_id': entry['hadm_id'],
                        'code': meta['code_desc'],
                        'clnote': cl_note,
                        'feedback': generated_text.split('## Final Response')[-1],
                        'ori_rational': spe_ans,
                    })
        ans_text = text_list

        out_list.append({
            'subject_id': entry['subject_id'],
            'hadm_id': entry['hadm_id'],
            'ans': ans_text,
            'label': label_codes,
            'extracted_codes': correct_codes,
            'ori_ans': ans,
            'ori_code': extracted_codes,

        })
        print('ans', ans)
        print('##########################')
        print('ans_text', ans_text)
        print('##########################')
        print(label_codes)
        print('ori', x_codes)
        print(correct_codes)
    else:
        out_list.append({
            'subject_id': entry['subject_id'],
            'hadm_id': entry['hadm_id'],
            'ans': 'No codes need to be judged! We skip this!',
            'label': entry['label'],
            'extracted_codes': [],
            'ori_ans': entry['ans'],
            'ori_code': extracted_codes,
        })

with open('output/round_1_2_store.json', 'w') as file:
    json.dump(store_list, file, indent=4)
with open('output/round_1_2.json', 'w') as file:
    json.dump(out_list, file, indent=4)
