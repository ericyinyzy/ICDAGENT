import torch
from transformers import AutoTokenizer
from vllm import LLM, SamplingParams
import json
import os
import re
from vllm.lora.request import LoRARequest

# Initialize tokenizer and model
import torch
from safetensors import safe_open

from safetensors import safe_open
from safetensors.torch import save_file
import torch


tokenizer = AutoTokenizer.from_pretrained("/path/to/R_crit_agent")

sampling_params = SamplingParams(temperature=0.6, top_p=0.95, top_k=20, max_tokens=2048)
llm = LLM(
    model="/path/to/R_crit_agent",
    dtype="bfloat16",
    tensor_parallel_size=torch.cuda.device_count(),
    # max_lora_rank=32,
    gpu_memory_utilization=0.9,
    trust_remote_code=True,
    max_model_len=32768,
    enforce_eager=False,
    # enable_lora=True
    # Remove peft_model_path parameter
)
notes = json.load(
    open('output/round_1_2_store.json', 'r'))
filelist=json.load(open('output/round_1_2.json', 'r'))
sortlist=[dict['subject_id']+'_'+dict['hadm_id'] for dict in filelist]

clinical_note_file = json.load(open('/path/to/1ksamples_wcorelation.json', 'r'))

code_descript = json.load(open('/path/to/code_descriptions_ICD10.json', 'r'))


# Helper functions
def map_mc2mctxt(codes):
    return "\n".join(f"{code}: {code_descript[code.replace('.','')]}" for code in codes if code in code_descript)


def map_mc2mctxt2(codes):
    return "\n".join(f"{code}({code_descript[code.replace('.','')]})" for code in codes if code in code_descript)



def extract_icd_codes(text):
    pattern = r'\|([0A-Z][^|]*)\|'
    return re.findall(pattern, text)


store_list = []


def seperate_ans(ans, codes):
    code_dict = {}
    for para in ans:
        sub_codes = extract_icd_codes(para)
        if len(sub_codes) != 0:
            sub_codes = ['|' + code + '|' for code in sub_codes]
        for code in sub_codes:
            if code not in code_dict:
                code_dict[code] = []
                code_dict[code].append(para)
            else:
                if len(code_dict[code])<3 and len(para.split(' '))<20000:
                    code_dict[code].append(para)
    for k, v in code_dict.items():
        if len(v) == 1:
            code_dict[k] = v[0]
        elif len(v) > 1:
            code_dict[k] = '\n\n'.join(v)
        else:
            raise ValueError
    return code_dict


count = 0
out_list=[]
print(len(notes))
batch_size = 12
for noteidx,entry in enumerate(notes):
    candidates = ['|' + code + '|' for code in set(entry['extracted_labels'])]
    extracted_codes=[]
    sub_id = entry['subject_id']
    hadm_id = entry['hadm_id']
    sub_index = sub_id + '_' + hadm_id
    put_index = sortlist.index(sub_index)
    for code in candidates:
        if code not in filelist[put_index]['extracted_codes']:
            extracted_codes.append(code)
    print('extract',extracted_codes)
    print('ori',filelist[put_index]['extracted_codes'])
    print('candidate',candidates)

    if len(extracted_codes) > 0:

        ans = entry['ans']
        xxx = ans.split('## Final Response')[0]
        # print(xxx)
        kk = xxx.split('\n\n')
        sep_ans_dict = seperate_ans(kk, extracted_codes)
        x_codes = list(sep_ans_dict.keys())

        cl_note = entry['clnote']

        code_batches = [x_codes[i:i + batch_size] for i in range(0, len(x_codes), batch_size)]
        text_list = {}
        correct_codes = []
        for batch in code_batches:
            prompt_batch, meta_batch = [], []
            for code in batch:

                spe_ans = sep_ans_dict[code]
                code_desc = map_mc2mctxt([code])
                code_supp = map_mc2mctxt2([code])

                messages = [
                    {
                        "role": "system",
                        'content': (
                            "You are an expert medical ICD-10 coding auditor. "
                            "Your mission is to rigorously audit a predicted ICD-10 code based on a patient's clinical note and the reasoning clues provided by a model.\n\n"
                            "You must perform a structured, multi-step validation:\n"
                            "1. **Evidence Verification:** Confirm that every reasoning clue is explicitly present in the clinical note. The evidence must be a direct quote or a very close paraphrase.\n"
                            "2. **Reasoning & Justification:** Ensure the link between the evidence and the inferred condition is medically sound and meets the official definition for the ICD-10 code.\n"
                        ),
                    },

                    {
                        "role": "user",
                        "content": (
                            f"Here is the clinical Note:\n{cl_note}\n\n"
                            f"The target candidate ICD Code you need to judge:\n{code_desc}\n\n"
                            f"The model's predicted rationale on this target code:\n{spe_ans}\n\n"
                            "Please think step by step to formulate your final judgment.\n\n"
                            "Your final output must strictly follow one of these formats:\n"
                            "1.If the code is correct: '|xxx| is a correct ICD code because the clinical note mentions...'\n"
                            "2.If the code is incorrect: '|xxx| is not a correct ICD code because... [state the specific reason, e.g., the evidence is missing, a more specific code is required, or it violates an exclusion rule].'\n"

                        ),
                    },
                ]

                text_prompt = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
                prompt_batch.append(text_prompt)
                meta_batch.append({
                    'code': code,
                    'rational':spe_ans,
                    'code_desc': code_desc,
                })
            # sampling_params = SamplingParams(temperature=0.7, top_p=0.8, repetition_penalty=1.05, max_tokens=8192)
            outputs = llm.generate(prompt_batch, sampling_params)

            for meta, output in zip(meta_batch, outputs):

                generated_text = output.outputs[0].text
                if 'is a correct' in generated_text:
                    correct_codes.append(meta['code'])
                    filelist[put_index]['extracted_codes'].append(meta['code'])
                    filelist[put_index]['ans'][meta['code']] = generated_text.split('## Final Response')[-1]

            print('label_codes', filelist[put_index]['label'])
            print('correct_codes', correct_codes)


with open('outout/final_explanations.json', 'w') as file:
    json.dump(filelist, file, indent=4)
